package com.google.android.gms.measurement.internal;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.annotation.MainThread;
import android.support.annotation.WorkerThread;
import com.google.android.gms.common.internal.zzaa;

class zzs extends BroadcastReceiver {
    static final String fx;
    private final zzx aqw;
    private boolean fy;
    private boolean fz;

    /* renamed from: com.google.android.gms.measurement.internal.zzs.1 */
    class C03081 implements Runnable {
        final /* synthetic */ boolean asV;
        final /* synthetic */ zzs asW;

        C03081(zzs com_google_android_gms_measurement_internal_zzs, boolean z) {
            this.asW = com_google_android_gms_measurement_internal_zzs;
            this.asV = z;
        }

        public void run() {
            this.asW.aqw.zzaw(this.asV);
        }
    }

    static {
        fx = zzs.class.getName();
    }

    zzs(zzx com_google_android_gms_measurement_internal_zzx) {
        zzaa.zzy(com_google_android_gms_measurement_internal_zzx);
        this.aqw = com_google_android_gms_measurement_internal_zzx;
    }

    private Context getContext() {
        return this.aqw.getContext();
    }

    private zzq zzbwb() {
        return this.aqw.zzbwb();
    }

    @WorkerThread
    public boolean isRegistered() {
        this.aqw.zzzx();
        return this.fy;
    }

    @MainThread
    public void onReceive(Context context, Intent intent) {
        this.aqw.zzacj();
        String action = intent.getAction();
        zzbwb().zzbxe().zzj("NetworkBroadcastReceiver received action", action);
        if ("android.net.conn.CONNECTIVITY_CHANGE".equals(action)) {
            boolean zzagk = this.aqw.zzbxv().zzagk();
            if (this.fz != zzagk) {
                this.fz = zzagk;
                this.aqw.zzbwa().zzm(new C03081(this, zzagk));
                return;
            }
            return;
        }
        zzbwb().zzbxa().zzj("NetworkBroadcastReceiver received unknown action", action);
    }

    @WorkerThread
    public void unregister() {
        this.aqw.zzacj();
        this.aqw.zzzx();
        if (isRegistered()) {
            zzbwb().zzbxe().log("Unregistering connectivity change receiver");
            this.fy = false;
            this.fz = false;
            try {
                getContext().unregisterReceiver(this);
            } catch (IllegalArgumentException e) {
                zzbwb().zzbwy().zzj("Failed to unregister the network broadcast receiver", e);
            }
        }
    }

    @WorkerThread
    public void zzagh() {
        this.aqw.zzacj();
        this.aqw.zzzx();
        if (!this.fy) {
            getContext().registerReceiver(this, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
            this.fz = this.aqw.zzbxv().zzagk();
            zzbwb().zzbxe().zzj("Registering connectivity change receiver. Network connected", Boolean.valueOf(this.fz));
            this.fy = true;
        }
    }
}
