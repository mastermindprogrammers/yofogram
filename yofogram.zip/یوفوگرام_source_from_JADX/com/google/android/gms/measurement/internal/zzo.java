package com.google.android.gms.measurement.internal;

import android.annotation.TargetApi;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabaseLockedException;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteFullException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.SystemClock;
import android.support.annotation.WorkerThread;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import com.google.android.gms.common.util.zze;

public class zzo extends zzaa {
    private final zza asx;
    private boolean asy;

    @TargetApi(11)
    private class zza extends SQLiteOpenHelper {
        final /* synthetic */ zzo asz;

        zza(zzo com_google_android_gms_measurement_internal_zzo, Context context, String str) {
            this.asz = com_google_android_gms_measurement_internal_zzo;
            super(context, str, null, 1);
        }

        @WorkerThread
        public SQLiteDatabase getWritableDatabase() {
            try {
                return super.getWritableDatabase();
            } catch (SQLiteException e) {
                if (VERSION.SDK_INT < 11 || !(e instanceof SQLiteDatabaseLockedException)) {
                    this.asz.zzbwb().zzbwy().log("Opening the local database failed, dropping and recreating it");
                    String zzade = this.asz.zzade();
                    if (!this.asz.getContext().getDatabasePath(zzade).delete()) {
                        this.asz.zzbwb().zzbwy().zzj("Failed to delete corrupted local db file", zzade);
                    }
                    try {
                        return super.getWritableDatabase();
                    } catch (SQLiteException e2) {
                        this.asz.zzbwb().zzbwy().zzj("Failed to open local database. Events will bypass local storage", e2);
                        return null;
                    }
                }
                throw e2;
            }
        }

        @WorkerThread
        public void onCreate(SQLiteDatabase sQLiteDatabase) {
            zze.zza(this.asz.zzbwb(), sQLiteDatabase);
        }

        @WorkerThread
        public void onOpen(SQLiteDatabase sQLiteDatabase) {
            if (VERSION.SDK_INT < 15) {
                Cursor rawQuery = sQLiteDatabase.rawQuery("PRAGMA journal_mode=memory", null);
                try {
                    rawQuery.moveToFirst();
                } finally {
                    rawQuery.close();
                }
            }
            zze.zza(this.asz.zzbwb(), sQLiteDatabase, "messages", "create table if not exists messages ( type INTEGER NOT NULL, entry BLOB NOT NULL)", "type,entry", null);
        }

        @WorkerThread
        public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        }
    }

    zzo(zzx com_google_android_gms_measurement_internal_zzx) {
        super(com_google_android_gms_measurement_internal_zzx);
        this.asx = new zza(this, getContext(), zzade());
    }

    @WorkerThread
    @TargetApi(11)
    private boolean zza(int i, byte[] bArr) {
        zzaby();
        zzzx();
        if (this.asy) {
            return false;
        }
        ContentValues contentValues = new ContentValues();
        contentValues.put("type", Integer.valueOf(i));
        contentValues.put("entry", bArr);
        zzbwd().zzbvb();
        int i2 = 0;
        int i3 = 5;
        while (i2 < 5) {
            SQLiteDatabase sQLiteDatabase = null;
            try {
                sQLiteDatabase = getWritableDatabase();
                if (sQLiteDatabase == null) {
                    this.asy = true;
                    if (sQLiteDatabase != null) {
                        sQLiteDatabase.close();
                    }
                    return false;
                }
                sQLiteDatabase.beginTransaction();
                long j = 0;
                Cursor rawQuery = sQLiteDatabase.rawQuery("select count(1) from messages", null);
                if (rawQuery != null && rawQuery.moveToFirst()) {
                    j = rawQuery.getLong(0);
                }
                if (j >= 100000) {
                    zzbwb().zzbwy().log("Data loss, local db full");
                    j = (100000 - j) + 1;
                    long delete = (long) sQLiteDatabase.delete("messages", "rowid in (select rowid from messages order by rowid asc limit ?)", new String[]{Long.toString(j)});
                    if (delete != j) {
                        zzbwb().zzbwy().zzd("Different delete count than expected in local db. expected, received, difference", Long.valueOf(j), Long.valueOf(delete), Long.valueOf(j - delete));
                    }
                }
                sQLiteDatabase.insertOrThrow("messages", null, contentValues);
                sQLiteDatabase.setTransactionSuccessful();
                sQLiteDatabase.endTransaction();
                if (sQLiteDatabase != null) {
                    sQLiteDatabase.close();
                }
                return true;
            } catch (SQLiteFullException e) {
                zzbwb().zzbwy().zzj("Error writing entry to local database", e);
                this.asy = true;
                if (sQLiteDatabase != null) {
                    sQLiteDatabase.close();
                }
                i2++;
            } catch (SQLiteException e2) {
                if (VERSION.SDK_INT < 11 || !(e2 instanceof SQLiteDatabaseLockedException)) {
                    if (sQLiteDatabase != null) {
                        if (sQLiteDatabase.inTransaction()) {
                            sQLiteDatabase.endTransaction();
                        }
                    }
                    zzbwb().zzbwy().zzj("Error writing entry to local database", e2);
                    this.asy = true;
                } else {
                    SystemClock.sleep((long) i3);
                    i3 += 20;
                }
                if (sQLiteDatabase != null) {
                    sQLiteDatabase.close();
                }
                i2++;
            } catch (Throwable th) {
                if (sQLiteDatabase != null) {
                    sQLiteDatabase.close();
                }
            }
        }
        zzbwb().zzbxa().log("Failed to write entry to local database");
        return false;
    }

    public /* bridge */ /* synthetic */ Context getContext() {
        return super.getContext();
    }

    @WorkerThread
    SQLiteDatabase getWritableDatabase() {
        if (this.asy) {
            return null;
        }
        SQLiteDatabase writableDatabase = this.asx.getWritableDatabase();
        if (writableDatabase != null) {
            return writableDatabase;
        }
        this.asy = true;
        return null;
    }

    public boolean zza(EventParcel eventParcel) {
        Parcel obtain = Parcel.obtain();
        eventParcel.writeToParcel(obtain, 0);
        byte[] marshall = obtain.marshall();
        obtain.recycle();
        if (marshall.length <= AccessibilityNodeInfoCompat.ACTION_SET_SELECTION) {
            return zza(0, marshall);
        }
        zzbwb().zzbxa().log("Event is too long for local database. Sending event directly to service");
        return false;
    }

    public boolean zza(UserAttributeParcel userAttributeParcel) {
        Parcel obtain = Parcel.obtain();
        userAttributeParcel.writeToParcel(obtain, 0);
        byte[] marshall = obtain.marshall();
        obtain.recycle();
        if (marshall.length <= AccessibilityNodeInfoCompat.ACTION_SET_SELECTION) {
            return zza(1, marshall);
        }
        zzbwb().zzbxa().log("User property too long for local database. Sending directly to service");
        return false;
    }

    public /* bridge */ /* synthetic */ void zzaby() {
        super.zzaby();
    }

    public /* bridge */ /* synthetic */ zze zzabz() {
        return super.zzabz();
    }

    String zzade() {
        return zzbwd().zzbus();
    }

    public /* bridge */ /* synthetic */ void zzbvo() {
        super.zzbvo();
    }

    public /* bridge */ /* synthetic */ zzc zzbvp() {
        return super.zzbvp();
    }

    public /* bridge */ /* synthetic */ zzac zzbvq() {
        return super.zzbvq();
    }

    public /* bridge */ /* synthetic */ zzn zzbvr() {
        return super.zzbvr();
    }

    public /* bridge */ /* synthetic */ zzg zzbvs() {
        return super.zzbvs();
    }

    public /* bridge */ /* synthetic */ zzae zzbvt() {
        return super.zzbvt();
    }

    public /* bridge */ /* synthetic */ zzad zzbvu() {
        return super.zzbvu();
    }

    public /* bridge */ /* synthetic */ zzo zzbvv() {
        return super.zzbvv();
    }

    public /* bridge */ /* synthetic */ zze zzbvw() {
        return super.zzbvw();
    }

    public /* bridge */ /* synthetic */ zzal zzbvx() {
        return super.zzbvx();
    }

    public /* bridge */ /* synthetic */ zzv zzbvy() {
        return super.zzbvy();
    }

    public /* bridge */ /* synthetic */ zzag zzbvz() {
        return super.zzbvz();
    }

    public /* bridge */ /* synthetic */ zzw zzbwa() {
        return super.zzbwa();
    }

    public /* bridge */ /* synthetic */ zzq zzbwb() {
        return super.zzbwb();
    }

    public /* bridge */ /* synthetic */ zzt zzbwc() {
        return super.zzbwc();
    }

    public /* bridge */ /* synthetic */ zzd zzbwd() {
        return super.zzbwd();
    }

    boolean zzbwn() {
        return getContext().getDatabasePath(zzade()).exists();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    @android.annotation.TargetApi(11)
    public java.util.List<com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable> zzxe(int r14) {
        /*
        r13 = this;
        r13.zzzx();
        r13.zzaby();
        r0 = r13.asy;
        if (r0 == 0) goto L_0x000c;
    L_0x000a:
        r0 = 0;
    L_0x000b:
        return r0;
    L_0x000c:
        r10 = new java.util.ArrayList;
        r10.<init>();
        r0 = r13.zzbwn();
        if (r0 != 0) goto L_0x0019;
    L_0x0017:
        r0 = r10;
        goto L_0x000b;
    L_0x0019:
        r9 = 5;
        r0 = 0;
        r11 = r0;
    L_0x001c:
        r0 = 5;
        if (r11 >= r0) goto L_0x0193;
    L_0x001f:
        r1 = 0;
        r0 = r13.getWritableDatabase();	 Catch:{ SQLiteFullException -> 0x01a9, SQLiteException -> 0x01a6 }
        if (r0 != 0) goto L_0x0030;
    L_0x0026:
        r1 = 1;
        r13.asy = r1;	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        if (r0 == 0) goto L_0x002e;
    L_0x002b:
        r0.close();
    L_0x002e:
        r0 = 0;
        goto L_0x000b;
    L_0x0030:
        r0.beginTransaction();	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r1 = "messages";
        r2 = 3;
        r2 = new java.lang.String[r2];	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r3 = 0;
        r4 = "rowid";
        r2[r3] = r4;	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r3 = 1;
        r4 = "type";
        r2[r3] = r4;	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r3 = 2;
        r4 = "entry";
        r2[r3] = r4;	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r3 = 0;
        r4 = 0;
        r5 = 0;
        r6 = 0;
        r7 = "rowid asc";
        r8 = java.lang.Integer.toString(r14);	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r6 = r0.query(r1, r2, r3, r4, r5, r6, r7, r8);	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r2 = -1;
    L_0x005c:
        r1 = r6.moveToNext();	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        if (r1 == 0) goto L_0x013b;
    L_0x0062:
        r1 = 0;
        r4 = r6.getLong(r1);	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r1 = 1;
        r1 = r6.getInt(r1);	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r2 = 2;
        r3 = r6.getBlob(r2);	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        if (r1 != 0) goto L_0x00cc;
    L_0x0073:
        r2 = android.os.Parcel.obtain();	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r1 = 0;
        r7 = r3.length;	 Catch:{ zza -> 0x0092 }
        r2.unmarshall(r3, r1, r7);	 Catch:{ zza -> 0x0092 }
        r1 = 0;
        r2.setDataPosition(r1);	 Catch:{ zza -> 0x0092 }
        r1 = com.google.android.gms.measurement.internal.EventParcel.CREATOR;	 Catch:{ zza -> 0x0092 }
        r1 = r1.createFromParcel(r2);	 Catch:{ zza -> 0x0092 }
        r1 = (com.google.android.gms.measurement.internal.EventParcel) r1;	 Catch:{ zza -> 0x0092 }
        r2.recycle();	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        if (r1 == 0) goto L_0x0090;
    L_0x008d:
        r10.add(r1);	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
    L_0x0090:
        r2 = r4;
        goto L_0x005c;
    L_0x0092:
        r1 = move-exception;
        r1 = r13.zzbwb();	 Catch:{ all -> 0x00a6 }
        r1 = r1.zzbwy();	 Catch:{ all -> 0x00a6 }
        r3 = "Failed to load event from local database";
        r1.log(r3);	 Catch:{ all -> 0x00a6 }
        r2.recycle();	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r2 = r4;
        goto L_0x005c;
    L_0x00a6:
        r1 = move-exception;
        r2.recycle();	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        throw r1;	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
    L_0x00ab:
        r1 = move-exception;
        r12 = r1;
        r1 = r0;
        r0 = r12;
    L_0x00af:
        r2 = r13.zzbwb();	 Catch:{ all -> 0x01a4 }
        r2 = r2.zzbwy();	 Catch:{ all -> 0x01a4 }
        r3 = "Error reading entries from local database";
        r2.zzj(r3, r0);	 Catch:{ all -> 0x01a4 }
        r0 = 1;
        r13.asy = r0;	 Catch:{ all -> 0x01a4 }
        if (r1 == 0) goto L_0x01ac;
    L_0x00c2:
        r1.close();
        r0 = r9;
    L_0x00c6:
        r1 = r11 + 1;
        r11 = r1;
        r9 = r0;
        goto L_0x001c;
    L_0x00cc:
        r2 = 1;
        if (r1 != r2) goto L_0x012b;
    L_0x00cf:
        r7 = android.os.Parcel.obtain();	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r2 = 0;
        r1 = 0;
        r8 = r3.length;	 Catch:{ zza -> 0x0108 }
        r7.unmarshall(r3, r1, r8);	 Catch:{ zza -> 0x0108 }
        r1 = 0;
        r7.setDataPosition(r1);	 Catch:{ zza -> 0x0108 }
        r1 = com.google.android.gms.measurement.internal.UserAttributeParcel.CREATOR;	 Catch:{ zza -> 0x0108 }
        r1 = r1.createFromParcel(r7);	 Catch:{ zza -> 0x0108 }
        r1 = (com.google.android.gms.measurement.internal.UserAttributeParcel) r1;	 Catch:{ zza -> 0x0108 }
        r7.recycle();	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
    L_0x00e8:
        if (r1 == 0) goto L_0x0090;
    L_0x00ea:
        r10.add(r1);	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        goto L_0x0090;
    L_0x00ee:
        r1 = move-exception;
        r12 = r1;
        r1 = r0;
        r0 = r12;
    L_0x00f2:
        r2 = android.os.Build.VERSION.SDK_INT;	 Catch:{ all -> 0x01a4 }
        r3 = 11;
        if (r2 < r3) goto L_0x0174;
    L_0x00f8:
        r2 = r0 instanceof android.database.sqlite.SQLiteDatabaseLockedException;	 Catch:{ all -> 0x01a4 }
        if (r2 == 0) goto L_0x0174;
    L_0x00fc:
        r2 = (long) r9;	 Catch:{ all -> 0x01a4 }
        android.os.SystemClock.sleep(r2);	 Catch:{ all -> 0x01a4 }
        r0 = r9 + 20;
    L_0x0102:
        if (r1 == 0) goto L_0x00c6;
    L_0x0104:
        r1.close();
        goto L_0x00c6;
    L_0x0108:
        r1 = move-exception;
        r1 = r13.zzbwb();	 Catch:{ all -> 0x011c }
        r1 = r1.zzbwy();	 Catch:{ all -> 0x011c }
        r3 = "Failed to load user property from local database";
        r1.log(r3);	 Catch:{ all -> 0x011c }
        r7.recycle();	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r1 = r2;
        goto L_0x00e8;
    L_0x011c:
        r1 = move-exception;
        r7.recycle();	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        throw r1;	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
    L_0x0121:
        r1 = move-exception;
        r12 = r1;
        r1 = r0;
        r0 = r12;
    L_0x0125:
        if (r1 == 0) goto L_0x012a;
    L_0x0127:
        r1.close();
    L_0x012a:
        throw r0;
    L_0x012b:
        r1 = r13.zzbwb();	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r1 = r1.zzbwy();	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r2 = "Unknown record type in local database";
        r1.log(r2);	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        goto L_0x0090;
    L_0x013b:
        r6.close();	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r1 = "messages";
        r4 = "rowid <= ?";
        r5 = 1;
        r5 = new java.lang.String[r5];	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r6 = 0;
        r2 = java.lang.Long.toString(r2);	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r5[r6] = r2;	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r1 = r0.delete(r1, r4, r5);	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r2 = r10.size();	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        if (r1 >= r2) goto L_0x0166;
    L_0x0158:
        r1 = r13.zzbwb();	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r1 = r1.zzbwy();	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r2 = "Fewer entries removed from local database than expected";
        r1.log(r2);	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
    L_0x0166:
        r0.setTransactionSuccessful();	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        r0.endTransaction();	 Catch:{ SQLiteFullException -> 0x00ab, SQLiteException -> 0x00ee, all -> 0x0121 }
        if (r0 == 0) goto L_0x0171;
    L_0x016e:
        r0.close();
    L_0x0171:
        r0 = r10;
        goto L_0x000b;
    L_0x0174:
        if (r1 == 0) goto L_0x017f;
    L_0x0176:
        r2 = r1.inTransaction();	 Catch:{ all -> 0x01a4 }
        if (r2 == 0) goto L_0x017f;
    L_0x017c:
        r1.endTransaction();	 Catch:{ all -> 0x01a4 }
    L_0x017f:
        r2 = r13.zzbwb();	 Catch:{ all -> 0x01a4 }
        r2 = r2.zzbwy();	 Catch:{ all -> 0x01a4 }
        r3 = "Error reading entries from local database";
        r2.zzj(r3, r0);	 Catch:{ all -> 0x01a4 }
        r0 = 1;
        r13.asy = r0;	 Catch:{ all -> 0x01a4 }
        r0 = r9;
        goto L_0x0102;
    L_0x0193:
        r0 = r13.zzbwb();
        r0 = r0.zzbxa();
        r1 = "Failed to read events from database in reasonable time";
        r0.log(r1);
        r0 = 0;
        goto L_0x000b;
    L_0x01a4:
        r0 = move-exception;
        goto L_0x0125;
    L_0x01a6:
        r0 = move-exception;
        goto L_0x00f2;
    L_0x01a9:
        r0 = move-exception;
        goto L_0x00af;
    L_0x01ac:
        r0 = r9;
        goto L_0x00c6;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.measurement.internal.zzo.zzxe(int):java.util.List<com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable>");
    }

    public /* bridge */ /* synthetic */ void zzzx() {
        super.zzzx();
    }

    protected void zzzy() {
    }
}
