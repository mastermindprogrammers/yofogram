package com.google.android.gms.measurement.internal;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.support.annotation.MainThread;
import com.google.android.gms.common.internal.zzaa;

public final class zzaf {
    private final zza avJ;
    private final Context mContext;
    private final Handler mHandler;

    public interface zza {
        boolean callServiceStopSelfResult(int i);

        Context getContext();
    }

    /* renamed from: com.google.android.gms.measurement.internal.zzaf.1 */
    class C02991 implements Runnable {
        final /* synthetic */ int aB;
        final /* synthetic */ zzx atw;
        final /* synthetic */ zzq atz;
        final /* synthetic */ zzaf avK;

        /* renamed from: com.google.android.gms.measurement.internal.zzaf.1.1 */
        class C02981 implements Runnable {
            final /* synthetic */ C02991 avL;

            C02981(C02991 c02991) {
                this.avL = c02991;
            }

            public void run() {
                if (this.avL.avK.avJ.callServiceStopSelfResult(this.avL.aB)) {
                    this.avL.atw.zzbwd().zzayi();
                    this.avL.atz.zzbxe().log("Local AppMeasurementService processed last upload request");
                }
            }
        }

        C02991(zzaf com_google_android_gms_measurement_internal_zzaf, zzx com_google_android_gms_measurement_internal_zzx, int i, zzq com_google_android_gms_measurement_internal_zzq) {
            this.avK = com_google_android_gms_measurement_internal_zzaf;
            this.atw = com_google_android_gms_measurement_internal_zzx;
            this.aB = i;
            this.atz = com_google_android_gms_measurement_internal_zzq;
        }

        public void run() {
            this.atw.zzbyj();
            this.atw.zzbye();
            this.avK.mHandler.post(new C02981(this));
        }
    }

    public zzaf(zza com_google_android_gms_measurement_internal_zzaf_zza) {
        this.mContext = com_google_android_gms_measurement_internal_zzaf_zza.getContext();
        zzaa.zzy(this.mContext);
        this.avJ = com_google_android_gms_measurement_internal_zzaf_zza;
        this.mHandler = new Handler();
    }

    private zzq zzbwb() {
        return zzx.zzdq(this.mContext).zzbwb();
    }

    public static boolean zzi(Context context, boolean z) {
        zzaa.zzy(context);
        return zzal.zzr(context, z ? "com.google.android.gms.measurement.PackageMeasurementService" : "com.google.android.gms.measurement.AppMeasurementService");
    }

    @MainThread
    public IBinder onBind(Intent intent) {
        if (intent == null) {
            zzbwb().zzbwy().log("onBind called with null intent");
            return null;
        }
        String action = intent.getAction();
        if ("com.google.android.gms.measurement.START".equals(action)) {
            return new zzy(zzx.zzdq(this.mContext));
        }
        zzbwb().zzbxa().zzj("onBind received unknown action", action);
        return null;
    }

    @MainThread
    public void onCreate() {
        zzx zzdq = zzx.zzdq(this.mContext);
        zzq zzbwb = zzdq.zzbwb();
        zzdq.zzbwd().zzayi();
        zzbwb.zzbxe().log("Local AppMeasurementService is starting up");
    }

    @MainThread
    public void onDestroy() {
        zzx zzdq = zzx.zzdq(this.mContext);
        zzq zzbwb = zzdq.zzbwb();
        zzdq.zzbwd().zzayi();
        zzbwb.zzbxe().log("Local AppMeasurementService is shutting down");
    }

    @MainThread
    public void onRebind(Intent intent) {
        if (intent == null) {
            zzbwb().zzbwy().log("onRebind called with null intent");
            return;
        }
        zzbwb().zzbxe().zzj("onRebind called. action", intent.getAction());
    }

    @MainThread
    public int onStartCommand(Intent intent, int i, int i2) {
        zzx zzdq = zzx.zzdq(this.mContext);
        zzq zzbwb = zzdq.zzbwb();
        if (intent == null) {
            zzbwb.zzbxa().log("AppMeasurementService started with null intent");
        } else {
            String action = intent.getAction();
            zzdq.zzbwd().zzayi();
            zzbwb.zzbxe().zze("Local AppMeasurementService called. startId, action", Integer.valueOf(i2), action);
            if ("com.google.android.gms.measurement.UPLOAD".equals(action)) {
                zzdq.zzbwa().zzm(new C02991(this, zzdq, i2, zzbwb));
            }
        }
        return 2;
    }

    @MainThread
    public boolean onUnbind(Intent intent) {
        if (intent == null) {
            zzbwb().zzbwy().log("onUnbind called with null intent");
        } else {
            zzbwb().zzbxe().zzj("onUnbind called for intent. action", intent.getAction());
        }
        return true;
    }
}
