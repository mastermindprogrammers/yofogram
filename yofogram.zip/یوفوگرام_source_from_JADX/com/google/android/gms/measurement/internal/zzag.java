package com.google.android.gms.measurement.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.MainThread;
import android.support.annotation.WorkerThread;
import com.google.android.gms.common.util.zze;

public class zzag extends zzaa {
    protected long avM;
    private final zzf avN;
    private final zzf avO;
    private Handler mHandler;

    /* renamed from: com.google.android.gms.measurement.internal.zzag.1 */
    class C03001 extends zzf {
        final /* synthetic */ zzag avP;

        C03001(zzag com_google_android_gms_measurement_internal_zzag, zzx com_google_android_gms_measurement_internal_zzx) {
            this.avP = com_google_android_gms_measurement_internal_zzag;
            super(com_google_android_gms_measurement_internal_zzx);
        }

        @WorkerThread
        public void run() {
            this.avP.zzbze();
        }
    }

    /* renamed from: com.google.android.gms.measurement.internal.zzag.2 */
    class C03012 extends zzf {
        final /* synthetic */ zzag avP;

        C03012(zzag com_google_android_gms_measurement_internal_zzag, zzx com_google_android_gms_measurement_internal_zzx) {
            this.avP = com_google_android_gms_measurement_internal_zzag;
            super(com_google_android_gms_measurement_internal_zzx);
        }

        @WorkerThread
        public void run() {
            this.avP.zzbzf();
        }
    }

    /* renamed from: com.google.android.gms.measurement.internal.zzag.3 */
    class C03023 implements Runnable {
        final /* synthetic */ zzag avP;
        final /* synthetic */ long avQ;

        C03023(zzag com_google_android_gms_measurement_internal_zzag, long j) {
            this.avP = com_google_android_gms_measurement_internal_zzag;
            this.avQ = j;
        }

        public void run() {
            this.avP.zzbn(this.avQ);
        }
    }

    /* renamed from: com.google.android.gms.measurement.internal.zzag.4 */
    class C03034 implements Runnable {
        final /* synthetic */ zzag avP;
        final /* synthetic */ long avQ;

        C03034(zzag com_google_android_gms_measurement_internal_zzag, long j) {
            this.avP = com_google_android_gms_measurement_internal_zzag;
            this.avQ = j;
        }

        public void run() {
            this.avP.zzbo(this.avQ);
        }
    }

    zzag(zzx com_google_android_gms_measurement_internal_zzx) {
        super(com_google_android_gms_measurement_internal_zzx);
        this.avN = new C03001(this, this.aqw);
        this.avO = new C03012(this, this.aqw);
    }

    @WorkerThread
    private void zzbn(long j) {
        zzzx();
        zzbzc();
        this.avN.cancel();
        this.avO.cancel();
        zzbwb().zzbxe().zzj("Activity resumed, time", Long.valueOf(j));
        this.avM = j;
        if (zzabz().currentTimeMillis() - zzbwc().atj.get() > zzbwc().atl.get()) {
            zzbwc().atk.set(true);
            zzbwc().atm.set(0);
        }
        if (zzbwc().atk.get()) {
            this.avN.zzx(Math.max(0, zzbwc().ati.get() - zzbwc().atm.get()));
        } else {
            this.avO.zzx(Math.max(0, 3600000 - zzbwc().atm.get()));
        }
    }

    @WorkerThread
    private void zzbo(long j) {
        zzzx();
        zzbzc();
        this.avN.cancel();
        this.avO.cancel();
        zzbwb().zzbxe().zzj("Activity paused, time", Long.valueOf(j));
        if (this.avM != 0) {
            zzbwc().atm.set(zzbwc().atm.get() + (j - this.avM));
        }
        zzbwc().atl.set(zzabz().currentTimeMillis());
    }

    private void zzbzc() {
        synchronized (this) {
            if (this.mHandler == null) {
                this.mHandler = new Handler(Looper.getMainLooper());
            }
        }
    }

    @WorkerThread
    private void zzbzf() {
        zzzx();
        zzck(false);
    }

    public /* bridge */ /* synthetic */ Context getContext() {
        return super.getContext();
    }

    public /* bridge */ /* synthetic */ void zzaby() {
        super.zzaby();
    }

    public /* bridge */ /* synthetic */ zze zzabz() {
        return super.zzabz();
    }

    public /* bridge */ /* synthetic */ void zzbvo() {
        super.zzbvo();
    }

    public /* bridge */ /* synthetic */ zzc zzbvp() {
        return super.zzbvp();
    }

    public /* bridge */ /* synthetic */ zzac zzbvq() {
        return super.zzbvq();
    }

    public /* bridge */ /* synthetic */ zzn zzbvr() {
        return super.zzbvr();
    }

    public /* bridge */ /* synthetic */ zzg zzbvs() {
        return super.zzbvs();
    }

    public /* bridge */ /* synthetic */ zzae zzbvt() {
        return super.zzbvt();
    }

    public /* bridge */ /* synthetic */ zzad zzbvu() {
        return super.zzbvu();
    }

    public /* bridge */ /* synthetic */ zzo zzbvv() {
        return super.zzbvv();
    }

    public /* bridge */ /* synthetic */ zze zzbvw() {
        return super.zzbvw();
    }

    public /* bridge */ /* synthetic */ zzal zzbvx() {
        return super.zzbvx();
    }

    public /* bridge */ /* synthetic */ zzv zzbvy() {
        return super.zzbvy();
    }

    public /* bridge */ /* synthetic */ zzag zzbvz() {
        return super.zzbvz();
    }

    public /* bridge */ /* synthetic */ zzw zzbwa() {
        return super.zzbwa();
    }

    public /* bridge */ /* synthetic */ zzq zzbwb() {
        return super.zzbwb();
    }

    public /* bridge */ /* synthetic */ zzt zzbwc() {
        return super.zzbwc();
    }

    public /* bridge */ /* synthetic */ zzd zzbwd() {
        return super.zzbwd();
    }

    @MainThread
    protected void zzbzb() {
        zzbwa().zzm(new C03023(this, zzabz().elapsedRealtime()));
    }

    @MainThread
    protected void zzbzd() {
        zzbwa().zzm(new C03034(this, zzabz().elapsedRealtime()));
    }

    @WorkerThread
    protected void zzbze() {
        zzzx();
        zzbwb().zzbxe().zzj("Session started, time", Long.valueOf(zzabz().elapsedRealtime()));
        zzbwc().atk.set(false);
        zzbvq().zzf("auto", "_s", new Bundle());
    }

    @WorkerThread
    public boolean zzck(boolean z) {
        zzzx();
        zzacj();
        long elapsedRealtime = zzabz().elapsedRealtime();
        if (this.avM == 0) {
            this.avM = elapsedRealtime - 3600000;
        }
        long j = elapsedRealtime - this.avM;
        if (z || j >= 1000) {
            zzbwc().atm.set(j);
            zzbwb().zzbxe().zzj("Recording user engagement, ms", Long.valueOf(j));
            Bundle bundle = new Bundle();
            bundle.putLong("_et", j);
            zzad.zza(zzbvu().zzbyt(), bundle);
            zzbvq().zzf("auto", "_e", bundle);
            this.avM = elapsedRealtime;
            this.avO.cancel();
            this.avO.zzx(Math.max(0, 3600000 - zzbwc().atm.get()));
            return true;
        }
        zzbwb().zzbxe().zzj("Screen exposed for less than 1000 ms. Event not sent. time", Long.valueOf(j));
        return false;
    }

    public /* bridge */ /* synthetic */ void zzzx() {
        super.zzzx();
    }

    protected void zzzy() {
    }
}
