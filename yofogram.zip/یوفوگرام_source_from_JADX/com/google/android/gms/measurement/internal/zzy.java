package com.google.android.gms.measurement.internal;

import android.os.Binder;
import android.support.annotation.BinderThread;
import android.support.annotation.Nullable;
import android.support.annotation.WorkerThread;
import android.text.TextUtils;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.common.util.zzx;
import com.google.android.gms.common.zze;
import com.google.android.gms.measurement.AppMeasurement.zzf;
import com.google.android.gms.measurement.internal.zzm.zza;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import org.telegram.messenger.exoplayer.C0858C;

public class zzy extends zza {
    private final zzx aqw;
    private Boolean auE;
    @Nullable
    private String auF;

    /* renamed from: com.google.android.gms.measurement.internal.zzy.1 */
    class C03141 implements Runnable {
        final /* synthetic */ AppMetadata auG;
        final /* synthetic */ zzy auH;

        C03141(zzy com_google_android_gms_measurement_internal_zzy, AppMetadata appMetadata) {
            this.auH = com_google_android_gms_measurement_internal_zzy;
            this.auG = appMetadata;
        }

        public void run() {
            this.auH.aqw.zzbyj();
            this.auH.zzmr(this.auG.ard);
            this.auH.aqw.zzc(this.auG);
        }
    }

    /* renamed from: com.google.android.gms.measurement.internal.zzy.2 */
    class C03152 implements Runnable {
        final /* synthetic */ AppMetadata auG;
        final /* synthetic */ zzy auH;
        final /* synthetic */ EventParcel auI;

        C03152(zzy com_google_android_gms_measurement_internal_zzy, AppMetadata appMetadata, EventParcel eventParcel) {
            this.auH = com_google_android_gms_measurement_internal_zzy;
            this.auG = appMetadata;
            this.auI = eventParcel;
        }

        public void run() {
            this.auH.aqw.zzbyj();
            this.auH.zzmr(this.auG.ard);
            this.auH.aqw.zzb(this.auI, this.auG);
        }
    }

    /* renamed from: com.google.android.gms.measurement.internal.zzy.3 */
    class C03163 implements Runnable {
        final /* synthetic */ String alm;
        final /* synthetic */ zzy auH;
        final /* synthetic */ EventParcel auI;
        final /* synthetic */ String auJ;

        C03163(zzy com_google_android_gms_measurement_internal_zzy, String str, EventParcel eventParcel, String str2) {
            this.auH = com_google_android_gms_measurement_internal_zzy;
            this.auJ = str;
            this.auI = eventParcel;
            this.alm = str2;
        }

        public void run() {
            this.auH.aqw.zzbyj();
            this.auH.zzmr(this.auJ);
            this.auH.aqw.zzb(this.auI, this.alm);
        }
    }

    /* renamed from: com.google.android.gms.measurement.internal.zzy.4 */
    class C03174 implements Callable<byte[]> {
        final /* synthetic */ String alm;
        final /* synthetic */ zzy auH;
        final /* synthetic */ EventParcel auI;

        C03174(zzy com_google_android_gms_measurement_internal_zzy, EventParcel eventParcel, String str) {
            this.auH = com_google_android_gms_measurement_internal_zzy;
            this.auI = eventParcel;
            this.alm = str;
        }

        public /* synthetic */ Object call() throws Exception {
            return zzbyl();
        }

        public byte[] zzbyl() throws Exception {
            this.auH.aqw.zzbyj();
            return this.auH.aqw.zza(this.auI, this.alm);
        }
    }

    /* renamed from: com.google.android.gms.measurement.internal.zzy.5 */
    class C03185 implements Runnable {
        final /* synthetic */ AppMetadata auG;
        final /* synthetic */ zzy auH;
        final /* synthetic */ UserAttributeParcel auK;

        C03185(zzy com_google_android_gms_measurement_internal_zzy, AppMetadata appMetadata, UserAttributeParcel userAttributeParcel) {
            this.auH = com_google_android_gms_measurement_internal_zzy;
            this.auG = appMetadata;
            this.auK = userAttributeParcel;
        }

        public void run() {
            this.auH.aqw.zzbyj();
            this.auH.zzmr(this.auG.ard);
            this.auH.aqw.zzc(this.auK, this.auG);
        }
    }

    /* renamed from: com.google.android.gms.measurement.internal.zzy.6 */
    class C03196 implements Runnable {
        final /* synthetic */ AppMetadata auG;
        final /* synthetic */ zzy auH;
        final /* synthetic */ UserAttributeParcel auK;

        C03196(zzy com_google_android_gms_measurement_internal_zzy, AppMetadata appMetadata, UserAttributeParcel userAttributeParcel) {
            this.auH = com_google_android_gms_measurement_internal_zzy;
            this.auG = appMetadata;
            this.auK = userAttributeParcel;
        }

        public void run() {
            this.auH.aqw.zzbyj();
            this.auH.zzmr(this.auG.ard);
            this.auH.aqw.zzb(this.auK, this.auG);
        }
    }

    /* renamed from: com.google.android.gms.measurement.internal.zzy.7 */
    class C03207 implements Callable<List<zzak>> {
        final /* synthetic */ AppMetadata auG;
        final /* synthetic */ zzy auH;

        C03207(zzy com_google_android_gms_measurement_internal_zzy, AppMetadata appMetadata) {
            this.auH = com_google_android_gms_measurement_internal_zzy;
            this.auG = appMetadata;
        }

        public /* synthetic */ Object call() throws Exception {
            return zzbym();
        }

        public List<zzak> zzbym() throws Exception {
            this.auH.aqw.zzbyj();
            return this.auH.aqw.zzbvw().zzly(this.auG.packageName);
        }
    }

    /* renamed from: com.google.android.gms.measurement.internal.zzy.8 */
    class C03218 implements Runnable {
        final /* synthetic */ AppMetadata auG;
        final /* synthetic */ zzy auH;

        C03218(zzy com_google_android_gms_measurement_internal_zzy, AppMetadata appMetadata) {
            this.auH = com_google_android_gms_measurement_internal_zzy;
            this.auG = appMetadata;
        }

        public void run() {
            this.auH.aqw.zzbyj();
            this.auH.zzmr(this.auG.ard);
            this.auH.aqw.zzd(this.auG);
        }
    }

    /* renamed from: com.google.android.gms.measurement.internal.zzy.9 */
    class C03229 implements Runnable {
        final /* synthetic */ String alm;
        final /* synthetic */ zzy auH;
        final /* synthetic */ String auL;
        final /* synthetic */ String auM;
        final /* synthetic */ long auN;

        C03229(zzy com_google_android_gms_measurement_internal_zzy, String str, String str2, String str3, long j) {
            this.auH = com_google_android_gms_measurement_internal_zzy;
            this.auL = str;
            this.alm = str2;
            this.auM = str3;
            this.auN = j;
        }

        public void run() {
            if (this.auL == null) {
                this.auH.aqw.zzbvu().zza(this.alm, null);
                return;
            }
            zzf com_google_android_gms_measurement_AppMeasurement_zzf = new zzf();
            com_google_android_gms_measurement_AppMeasurement_zzf.aqz = this.auM;
            com_google_android_gms_measurement_AppMeasurement_zzf.aqA = this.auL;
            com_google_android_gms_measurement_AppMeasurement_zzf.aqB = this.auN;
            this.auH.aqw.zzbvu().zza(this.alm, com_google_android_gms_measurement_AppMeasurement_zzf);
        }
    }

    public zzy(zzx com_google_android_gms_measurement_internal_zzx) {
        this(com_google_android_gms_measurement_internal_zzx, null);
    }

    public zzy(zzx com_google_android_gms_measurement_internal_zzx, @Nullable String str) {
        zzaa.zzy(com_google_android_gms_measurement_internal_zzx);
        this.aqw = com_google_android_gms_measurement_internal_zzx;
        this.auF = str;
    }

    @BinderThread
    private void zzb(AppMetadata appMetadata, boolean z) {
        zzaa.zzy(appMetadata);
        zzn(appMetadata.packageName, z);
        this.aqw.zzbvx().zznb(appMetadata.aqZ);
    }

    @BinderThread
    private void zzn(String str, boolean z) throws SecurityException {
        if (TextUtils.isEmpty(str)) {
            this.aqw.zzbwb().zzbwy().log("Measurement Service called without app package");
            throw new SecurityException("Measurement Service called without app package");
        }
        try {
            zzo(str, z);
        } catch (SecurityException e) {
            this.aqw.zzbwb().zzbwy().zzj("Measurement Service called with invalid calling package", str);
            throw e;
        }
    }

    @BinderThread
    public List<UserAttributeParcel> zza(AppMetadata appMetadata, boolean z) {
        Object e;
        zzb(appMetadata, false);
        try {
            List<zzak> list = (List) this.aqw.zzbwa().zzd(new C03207(this, appMetadata)).get();
            List<UserAttributeParcel> arrayList = new ArrayList(list.size());
            for (zzak com_google_android_gms_measurement_internal_zzak : list) {
                if (z || !zzal.zzne(com_google_android_gms_measurement_internal_zzak.mName)) {
                    arrayList.add(new UserAttributeParcel(com_google_android_gms_measurement_internal_zzak));
                }
            }
            return arrayList;
        } catch (InterruptedException e2) {
            e = e2;
            this.aqw.zzbwb().zzbwy().zzj("Failed to get user attributes", e);
            return null;
        } catch (ExecutionException e3) {
            e = e3;
            this.aqw.zzbwb().zzbwy().zzj("Failed to get user attributes", e);
            return null;
        }
    }

    @BinderThread
    public void zza(long j, String str, String str2, String str3) {
        this.aqw.zzbwa().zzm(new C03229(this, str2, str3, str, j));
    }

    @BinderThread
    public void zza(AppMetadata appMetadata) {
        zzb(appMetadata, false);
        this.aqw.zzbwa().zzm(new C03218(this, appMetadata));
    }

    @BinderThread
    public void zza(EventParcel eventParcel, AppMetadata appMetadata) {
        zzaa.zzy(eventParcel);
        zzb(appMetadata, false);
        this.aqw.zzbwa().zzm(new C03152(this, appMetadata, eventParcel));
    }

    @BinderThread
    public void zza(EventParcel eventParcel, String str, String str2) {
        zzaa.zzy(eventParcel);
        zzaa.zzib(str);
        zzn(str, true);
        this.aqw.zzbwa().zzm(new C03163(this, str2, eventParcel, str));
    }

    @BinderThread
    public void zza(UserAttributeParcel userAttributeParcel, AppMetadata appMetadata) {
        zzaa.zzy(userAttributeParcel);
        zzb(appMetadata, false);
        if (userAttributeParcel.getValue() == null) {
            this.aqw.zzbwa().zzm(new C03185(this, appMetadata, userAttributeParcel));
        } else {
            this.aqw.zzbwa().zzm(new C03196(this, appMetadata, userAttributeParcel));
        }
    }

    @BinderThread
    public byte[] zza(EventParcel eventParcel, String str) {
        Object e;
        zzaa.zzib(str);
        zzaa.zzy(eventParcel);
        zzn(str, true);
        this.aqw.zzbwb().zzbxd().zzj("Log and bundle. event", eventParcel.name);
        long nanoTime = this.aqw.zzabz().nanoTime() / C0858C.MICROS_PER_SECOND;
        try {
            byte[] bArr = (byte[]) this.aqw.zzbwa().zze(new C03174(this, eventParcel, str)).get();
            if (bArr == null) {
                this.aqw.zzbwb().zzbwy().log("Log and bundle returned null");
                bArr = new byte[0];
            }
            this.aqw.zzbwb().zzbxd().zzd("Log and bundle processed. event, size, time_ms", eventParcel.name, Integer.valueOf(bArr.length), Long.valueOf((this.aqw.zzabz().nanoTime() / C0858C.MICROS_PER_SECOND) - nanoTime));
            return bArr;
        } catch (InterruptedException e2) {
            e = e2;
            this.aqw.zzbwb().zzbwy().zze("Failed to log and bundle. event, error", eventParcel.name, e);
            return null;
        } catch (ExecutionException e3) {
            e = e3;
            this.aqw.zzbwb().zzbwy().zze("Failed to log and bundle. event, error", eventParcel.name, e);
            return null;
        }
    }

    @BinderThread
    public void zzb(AppMetadata appMetadata) {
        zzb(appMetadata, false);
        this.aqw.zzbwa().zzm(new C03141(this, appMetadata));
    }

    @WorkerThread
    void zzmr(String str) {
        if (!TextUtils.isEmpty(str)) {
            String[] split = str.split(":", 2);
            if (split.length == 2) {
                try {
                    long longValue = Long.valueOf(split[0]).longValue();
                    if (longValue > 0) {
                        this.aqw.zzbwc().asY.zzg(split[1], longValue);
                    } else {
                        this.aqw.zzbwb().zzbxa().zzj("Combining sample with a non-positive weight", Long.valueOf(longValue));
                    }
                } catch (NumberFormatException e) {
                    this.aqw.zzbwb().zzbxa().zzj("Combining sample with a non-number weight", split[0]);
                }
            }
        }
    }

    protected void zzo(String str, boolean z) throws SecurityException {
        if (z) {
            if (this.auE == null) {
                boolean z2;
                if (GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE.equals(this.auF) || zzx.zzf(this.aqw.getContext(), Binder.getCallingUid()) || com.google.android.gms.common.zzf.zzbv(this.aqw.getContext()).zza(this.aqw.getContext().getPackageManager(), Binder.getCallingUid())) {
                    zzx com_google_android_gms_measurement_internal_zzx = this.aqw;
                    z2 = true;
                } else {
                    z2 = false;
                }
                this.auE = Boolean.valueOf(z2);
            }
            if (this.auE.booleanValue()) {
                return;
            }
        }
        if (this.auF == null && zze.zzc(this.aqw.getContext(), Binder.getCallingUid(), str)) {
            this.auF = str;
        }
        if (!str.equals(this.auF)) {
            throw new SecurityException(String.format("Unknown calling package name '%s'.", new Object[]{str}));
        }
    }
}
