package com.google.android.gms.tasks;

public interface OnSuccessListener<TResult> {
    void onSuccess(TResult tResult);
}
