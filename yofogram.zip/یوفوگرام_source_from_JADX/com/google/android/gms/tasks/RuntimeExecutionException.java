package com.google.android.gms.tasks;

public class RuntimeExecutionException extends RuntimeException {
    public RuntimeExecutionException(Throwable th) {
        super(th);
    }
}
