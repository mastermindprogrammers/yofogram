package com.google.android.gms.signin.internal;

import android.os.RemoteException;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.signin.internal.zzd.zza;

public class zzb extends zza {
    public void zza(ConnectionResult connectionResult, AuthAccountResult authAccountResult) throws RemoteException {
    }

    public void zza(Status status, GoogleSignInAccount googleSignInAccount) throws RemoteException {
    }

    public void zzb(SignInResponse signInResponse) throws RemoteException {
    }

    public void zzej(Status status) throws RemoteException {
    }

    public void zzek(Status status) throws RemoteException {
    }
}
