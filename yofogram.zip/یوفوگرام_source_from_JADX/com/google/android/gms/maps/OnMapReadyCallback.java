package com.google.android.gms.maps;

public interface OnMapReadyCallback {
    void onMapReady(GoogleMap googleMap);
}
