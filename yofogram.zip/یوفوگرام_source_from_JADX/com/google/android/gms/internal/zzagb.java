package com.google.android.gms.internal;

import java.io.IOException;

public class zzagb extends IOException {
    public zzagb(String str) {
        super(str);
    }
}
