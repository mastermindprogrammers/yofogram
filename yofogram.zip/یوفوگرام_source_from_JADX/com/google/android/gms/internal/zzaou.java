package com.google.android.gms.internal;

import java.lang.reflect.Type;

public interface zzaou<T> {
    T zza(Type type);
}
