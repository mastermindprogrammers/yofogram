package com.google.android.gms.internal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.telegram.messenger.volley.Request.Method;
import org.telegram.ui.Components.VideoPlayer;
import takgram.markers.Slate;

public final class zzaqi extends zzapk<Object> {
    public static final zzapl bpG;
    private final zzaos boC;

    /* renamed from: com.google.android.gms.internal.zzaqi.1 */
    static class C01911 implements zzapl {
        C01911() {
        }

        public <T> zzapk<T> zza(zzaos com_google_android_gms_internal_zzaos, zzaqo<T> com_google_android_gms_internal_zzaqo_T) {
            return com_google_android_gms_internal_zzaqo_T.bB() == Object.class ? new zzaqi(null) : null;
        }
    }

    /* renamed from: com.google.android.gms.internal.zzaqi.2 */
    static /* synthetic */ class C01922 {
        static final /* synthetic */ int[] bpW;

        static {
            bpW = new int[zzaqq.values().length];
            try {
                bpW[zzaqq.BEGIN_ARRAY.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                bpW[zzaqq.BEGIN_OBJECT.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                bpW[zzaqq.STRING.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                bpW[zzaqq.NUMBER.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                bpW[zzaqq.BOOLEAN.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
            try {
                bpW[zzaqq.NULL.ordinal()] = 6;
            } catch (NoSuchFieldError e6) {
            }
        }
    }

    static {
        bpG = new C01911();
    }

    private zzaqi(zzaos com_google_android_gms_internal_zzaos) {
        this.boC = com_google_android_gms_internal_zzaos;
    }

    public void zza(zzaqr com_google_android_gms_internal_zzaqr, Object obj) throws IOException {
        if (obj == null) {
            com_google_android_gms_internal_zzaqr.bA();
            return;
        }
        zzapk zzk = this.boC.zzk(obj.getClass());
        if (zzk instanceof zzaqi) {
            com_google_android_gms_internal_zzaqr.by();
            com_google_android_gms_internal_zzaqr.bz();
            return;
        }
        zzk.zza(com_google_android_gms_internal_zzaqr, obj);
    }

    public Object zzb(zzaqp com_google_android_gms_internal_zzaqp) throws IOException {
        switch (C01922.bpW[com_google_android_gms_internal_zzaqp.bq().ordinal()]) {
            case Slate.TYPE_FELTTIP /*1*/:
                List arrayList = new ArrayList();
                com_google_android_gms_internal_zzaqp.beginArray();
                while (com_google_android_gms_internal_zzaqp.hasNext()) {
                    arrayList.add(zzb(com_google_android_gms_internal_zzaqp));
                }
                com_google_android_gms_internal_zzaqp.endArray();
                return arrayList;
            case Slate.TYPE_AIRBRUSH /*2*/:
                Map com_google_android_gms_internal_zzapw = new zzapw();
                com_google_android_gms_internal_zzaqp.beginObject();
                while (com_google_android_gms_internal_zzaqp.hasNext()) {
                    com_google_android_gms_internal_zzapw.put(com_google_android_gms_internal_zzaqp.nextName(), zzb(com_google_android_gms_internal_zzaqp));
                }
                com_google_android_gms_internal_zzaqp.endObject();
                return com_google_android_gms_internal_zzapw;
            case Slate.TYPE_FOUNTAIN_PEN /*3*/:
                return com_google_android_gms_internal_zzaqp.nextString();
            case Slate.SHAPE_FOUNTAIN_PEN /*4*/:
                return Double.valueOf(com_google_android_gms_internal_zzaqp.nextDouble());
            case VideoPlayer.STATE_ENDED /*5*/:
                return Boolean.valueOf(com_google_android_gms_internal_zzaqp.nextBoolean());
            case Method.TRACE /*6*/:
                com_google_android_gms_internal_zzaqp.nextNull();
                return null;
            default:
                throw new IllegalStateException();
        }
    }
}
