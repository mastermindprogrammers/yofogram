package com.google.android.gms.internal;

import java.io.IOException;

public final class zzaqs extends IOException {
    public zzaqs(String str) {
        super(str);
    }
}
