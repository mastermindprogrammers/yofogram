package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.android.gms.internal.zzss.zza;

public class zzsm extends zza {
    public void zzgv(int i) throws RemoteException {
    }
}
