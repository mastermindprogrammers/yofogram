package com.google.android.gms.internal;

public class zzj extends zzh {
    public zzj(Throwable th) {
        super(th);
    }
}
