package com.google.android.gms.internal;

public interface zzf {
    zzi zza(zzk<?> com_google_android_gms_internal_zzk_) throws zzr;
}
