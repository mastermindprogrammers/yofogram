package com.google.android.gms.internal;

public class zza extends zzr {
    public zza(zzi com_google_android_gms_internal_zzi) {
        super(com_google_android_gms_internal_zzi);
    }

    public String getMessage() {
        return super.getMessage();
    }
}
