package com.google.android.gms.internal;

import com.google.android.gms.common.api.zzc;

public class zzrv {
    public final zzqj Bq;
    public final int Br;
    public final zzc<?> Bs;

    public zzrv(zzqj com_google_android_gms_internal_zzqj, int i, zzc<?> com_google_android_gms_common_api_zzc_) {
        this.Bq = com_google_android_gms_internal_zzqj;
        this.Br = i;
        this.Bs = com_google_android_gms_common_api_zzc_;
    }
}
