package com.google.android.gms.internal;

public interface zzaoo {
    boolean zza(zzaop com_google_android_gms_internal_zzaop);

    boolean zzh(Class<?> cls);
}
