package com.google.android.gms.internal;

import java.io.IOException;

public abstract class zzapu {
    public static zzapu bph;

    public abstract void zzi(zzaqp com_google_android_gms_internal_zzaqp) throws IOException;
}
