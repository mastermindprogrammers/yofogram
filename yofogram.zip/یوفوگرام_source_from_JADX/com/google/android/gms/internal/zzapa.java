package com.google.android.gms.internal;

public final class zzapa extends zzaoy {
    public static final zzapa bou;

    static {
        bou = new zzapa();
    }

    public boolean equals(Object obj) {
        return this == obj || (obj instanceof zzapa);
    }

    public int hashCode() {
        return zzapa.class.hashCode();
    }
}
