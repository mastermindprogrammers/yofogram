package com.google.android.gms.internal;

import java.lang.reflect.Type;

public interface zzaox<T> {
    T zzb(zzaoy com_google_android_gms_internal_zzaoy, Type type, zzaow com_google_android_gms_internal_zzaow) throws zzapc;
}
