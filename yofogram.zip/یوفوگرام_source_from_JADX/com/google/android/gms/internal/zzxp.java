package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.zze;
import com.google.android.gms.common.internal.zzp;
import com.google.android.gms.signin.internal.zzd;

public interface zzxp extends zze {
    void connect();

    void zza(zzp com_google_android_gms_common_internal_zzp, boolean z);

    void zza(zzd com_google_android_gms_signin_internal_zzd);

    void zzcdc();
}
