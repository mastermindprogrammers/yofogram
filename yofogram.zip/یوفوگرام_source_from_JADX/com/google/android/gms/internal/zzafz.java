package com.google.android.gms.internal;

import java.io.IOException;
import java.io.InputStream;

public interface zzafz {
    void close();

    InputStream zzqz(String str) throws IOException;
}
