package com.google.android.gms.internal;

public final class zzaph extends zzapc {
    public zzaph(String str) {
        super(str);
    }

    public zzaph(String str, Throwable th) {
        super(str, th);
    }

    public zzaph(Throwable th) {
        super(th);
    }
}
