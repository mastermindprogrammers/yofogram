package com.google.android.gms.internal;

import android.support.annotation.NonNull;
import com.google.android.gms.common.api.Api.zzb;

public final class zzrx {
    public final zzrw<zzb> yi;
    public final zzsh<zzb> yj;

    public zzrx(@NonNull zzrw<zzb> com_google_android_gms_internal_zzrw_com_google_android_gms_common_api_Api_zzb, @NonNull zzsh<zzb> com_google_android_gms_internal_zzsh_com_google_android_gms_common_api_Api_zzb) {
        this.yi = com_google_android_gms_internal_zzrw_com_google_android_gms_common_api_Api_zzb;
        this.yj = com_google_android_gms_internal_zzsh_com_google_android_gms_common_api_Api_zzb;
    }
}
