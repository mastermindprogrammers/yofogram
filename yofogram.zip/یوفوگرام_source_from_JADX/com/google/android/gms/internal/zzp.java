package com.google.android.gms.internal;

public class zzp extends zzr {
    public zzp(zzi com_google_android_gms_internal_zzi) {
        super(com_google_android_gms_internal_zzi);
    }
}
