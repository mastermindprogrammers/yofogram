package com.google.android.gms.internal;

public class zzapc extends RuntimeException {
    public zzapc(String str) {
        super(str);
    }

    public zzapc(String str, Throwable th) {
        super(str, th);
    }

    public zzapc(Throwable th) {
        super(th);
    }
}
