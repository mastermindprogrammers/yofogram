package com.google.android.gms.internal;

public interface zzsa {
    void zzajb();
}
