package com.google.android.gms.internal;

public interface zzapl {
    <T> zzapk<T> zza(zzaos com_google_android_gms_internal_zzaos, zzaqo<T> com_google_android_gms_internal_zzaqo_T);
}
