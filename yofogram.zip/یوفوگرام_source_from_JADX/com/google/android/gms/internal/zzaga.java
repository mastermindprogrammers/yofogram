package com.google.android.gms.internal;

public class zzaga {
    public zzafz zzclf() {
        return new zzafy();
    }
}
