package com.google.android.gms.internal;

public final class zzaoz extends zzapc {
    public zzaoz(String str) {
        super(str);
    }

    public zzaoz(Throwable th) {
        super(th);
    }
}
