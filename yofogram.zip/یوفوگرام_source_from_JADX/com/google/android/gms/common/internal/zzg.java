package com.google.android.gms.common.internal;

import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.util.SimpleArrayMap;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.C0087R;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.util.zzi;
import com.google.android.gms.internal.zzsz;
import com.sahasoft.telegram.C0400R;
import net.hockeyapp.android.BuildConfig;
import org.telegram.messenger.volley.Request.Method;
import org.telegram.tgnet.TLRPC;
import org.telegram.ui.Components.Glow;
import org.telegram.ui.Components.VideoPlayer;
import takgram.markers.Slate;
import takgram.markers.TiledBitmapCanvas;

public final class zzg {
    private static final SimpleArrayMap<String, String> DO;

    static {
        DO = new SimpleArrayMap();
    }

    public static String zzcb(Context context) {
        String str = context.getApplicationInfo().name;
        if (TextUtils.isEmpty(str)) {
            str = context.getPackageName();
            try {
                str = zzsz.zzco(context).zzik(context.getPackageName()).toString();
            } catch (NameNotFoundException e) {
            }
        }
        return str;
    }

    @Nullable
    public static String zzg(Context context, int i) {
        Resources resources = context.getResources();
        switch (i) {
            case Slate.TYPE_FELTTIP /*1*/:
                return resources.getString(C0087R.string.common_google_play_services_install_title);
            case Slate.TYPE_AIRBRUSH /*2*/:
                return resources.getString(C0087R.string.common_google_play_services_update_title);
            case Slate.TYPE_FOUNTAIN_PEN /*3*/:
                return resources.getString(C0087R.string.common_google_play_services_enable_title);
            case Slate.SHAPE_FOUNTAIN_PEN /*4*/:
            case Method.TRACE /*6*/:
            case C0400R.styleable.MapAttrs_cameraMaxZoomPreference /*18*/:
                return null;
            case VideoPlayer.STATE_ENDED /*5*/:
                Log.e("GoogleApiAvailability", "An invalid account was specified when connecting. Please provide a valid account.");
                return zzu(context, "common_google_play_services_invalid_account_title");
            case Method.PATCH /*7*/:
                Log.e("GoogleApiAvailability", "Network error occurred. Please retry request later.");
                return zzu(context, "common_google_play_services_network_error_title");
            case Slate.FLAG_DEBUG_TILES /*8*/:
                Log.e("GoogleApiAvailability", "Internal error occurred. Please see logs for detailed information");
                return null;
            case BuildConfig.VERSION_CODE /*9*/:
                Log.e("GoogleApiAvailability", "Google Play services is invalid. Cannot recover.");
                return null;
            case TiledBitmapCanvas.DEFAULT_NUM_VERSIONS /*10*/:
                Log.e("GoogleApiAvailability", "Developer error occurred. Please see logs for detailed information");
                return null;
            case Glow.PRE_HONEYCOMB /*11*/:
                Log.e("GoogleApiAvailability", "The application is not licensed to the user.");
                return null;
            case TLRPC.USER_FLAG_PHONE /*16*/:
                Log.e("GoogleApiAvailability", "One of the API components you attempted to connect to is not available.");
                return null;
            case C0400R.styleable.MapAttrs_cameraMinZoomPreference /*17*/:
                Log.e("GoogleApiAvailability", "The specified account could not be signed in.");
                return zzu(context, "common_google_play_services_sign_in_failed_title");
            case C0400R.styleable.MapAttrs_latLngBoundsSouthWestLongitude /*20*/:
                Log.e("GoogleApiAvailability", "The current user profile is restricted and could not use authenticated features.");
                return zzu(context, "common_google_play_services_restricted_profile_title");
            default:
                Log.e("GoogleApiAvailability", "Unexpected error code " + i);
                return null;
        }
    }

    private static String zzg(Context context, String str, String str2) {
        Resources resources = context.getResources();
        String zzu = zzu(context, str);
        if (zzu == null) {
            zzu = resources.getString(C0087R.string.common_google_play_services_unknown_issue);
        }
        return String.format(resources.getConfiguration().locale, zzu, new Object[]{str2});
    }

    @NonNull
    public static String zzh(Context context, int i) {
        String zzu = i == 6 ? zzu(context, "common_google_play_services_resolution_required_title") : zzg(context, i);
        return zzu == null ? context.getResources().getString(C0087R.string.common_google_play_services_notification_ticker) : zzu;
    }

    @NonNull
    public static String zzi(Context context, int i) {
        Resources resources = context.getResources();
        String zzcb = zzcb(context);
        switch (i) {
            case Slate.TYPE_FELTTIP /*1*/:
                return resources.getString(C0087R.string.common_google_play_services_install_text, new Object[]{zzcb});
            case Slate.TYPE_AIRBRUSH /*2*/:
                if (zzi.zzci(context)) {
                    return resources.getString(C0087R.string.common_google_play_services_wear_update_text);
                }
                return resources.getString(C0087R.string.common_google_play_services_update_text, new Object[]{zzcb});
            case Slate.TYPE_FOUNTAIN_PEN /*3*/:
                return resources.getString(C0087R.string.common_google_play_services_enable_text, new Object[]{zzcb});
            case VideoPlayer.STATE_ENDED /*5*/:
                return zzg(context, "common_google_play_services_invalid_account_text", zzcb);
            case Method.PATCH /*7*/:
                return zzg(context, "common_google_play_services_network_error_text", zzcb);
            case BuildConfig.VERSION_CODE /*9*/:
                return resources.getString(C0087R.string.common_google_play_services_unsupported_text, new Object[]{zzcb});
            case TLRPC.USER_FLAG_PHONE /*16*/:
                return zzg(context, "common_google_play_services_api_unavailable_text", zzcb);
            case C0400R.styleable.MapAttrs_cameraMinZoomPreference /*17*/:
                return zzg(context, "common_google_play_services_sign_in_failed_text", zzcb);
            case C0400R.styleable.MapAttrs_cameraMaxZoomPreference /*18*/:
                return resources.getString(C0087R.string.common_google_play_services_updating_text, new Object[]{zzcb});
            case C0400R.styleable.MapAttrs_latLngBoundsSouthWestLongitude /*20*/:
                return zzg(context, "common_google_play_services_restricted_profile_text", zzcb);
            default:
                return resources.getString(C0087R.string.common_google_play_services_unknown_issue, new Object[]{zzcb});
        }
    }

    @NonNull
    public static String zzj(Context context, int i) {
        return i == 6 ? zzg(context, "common_google_play_services_resolution_required_text", zzcb(context)) : zzi(context, i);
    }

    @NonNull
    public static String zzk(Context context, int i) {
        Resources resources = context.getResources();
        switch (i) {
            case Slate.TYPE_FELTTIP /*1*/:
                return resources.getString(C0087R.string.common_google_play_services_install_button);
            case Slate.TYPE_AIRBRUSH /*2*/:
                return resources.getString(C0087R.string.common_google_play_services_update_button);
            case Slate.TYPE_FOUNTAIN_PEN /*3*/:
                return resources.getString(C0087R.string.common_google_play_services_enable_button);
            default:
                return resources.getString(17039370);
        }
    }

    @Nullable
    private static String zzu(Context context, String str) {
        synchronized (DO) {
            String str2 = (String) DO.get(str);
            if (str2 != null) {
                return str2;
            }
            Resources remoteResource = GooglePlayServicesUtil.getRemoteResource(context);
            if (remoteResource == null) {
                return null;
            }
            int identifier = remoteResource.getIdentifier(str, "string", GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE);
            if (identifier == 0) {
                String str3 = "GoogleApiAvailability";
                String str4 = "Missing resource: ";
                str2 = String.valueOf(str);
                Log.w(str3, str2.length() != 0 ? str4.concat(str2) : new String(str4));
                return null;
            }
            Object string = remoteResource.getString(identifier);
            if (TextUtils.isEmpty(string)) {
                str3 = "GoogleApiAvailability";
                str4 = "Got empty resource: ";
                str2 = String.valueOf(str);
                Log.w(str3, str2.length() != 0 ? str4.concat(str2) : new String(str4));
                return null;
            }
            DO.put(str, string);
            return string;
        }
    }
}
