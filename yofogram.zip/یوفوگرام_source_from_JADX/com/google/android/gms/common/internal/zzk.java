package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicInteger;

public final class zzk implements Callback {
    private final zza Ee;
    private final ArrayList<ConnectionCallbacks> Ef;
    final ArrayList<ConnectionCallbacks> Eg;
    private final ArrayList<OnConnectionFailedListener> Eh;
    private volatile boolean Ei;
    private final AtomicInteger Ej;
    private boolean Ek;
    private final Handler mHandler;
    private final Object zzako;

    public interface zza {
        boolean isConnected();

        Bundle zzapn();
    }

    public zzk(Looper looper, zza com_google_android_gms_common_internal_zzk_zza) {
        this.Ef = new ArrayList();
        this.Eg = new ArrayList();
        this.Eh = new ArrayList();
        this.Ei = false;
        this.Ej = new AtomicInteger(0);
        this.Ek = false;
        this.zzako = new Object();
        this.Ee = com_google_android_gms_common_internal_zzk_zza;
        this.mHandler = new Handler(looper, this);
    }

    public boolean handleMessage(Message message) {
        if (message.what == 1) {
            ConnectionCallbacks connectionCallbacks = (ConnectionCallbacks) message.obj;
            synchronized (this.zzako) {
                if (this.Ei && this.Ee.isConnected() && this.Ef.contains(connectionCallbacks)) {
                    connectionCallbacks.onConnected(this.Ee.zzapn());
                }
            }
            return true;
        }
        Log.wtf("GmsClientEvents", "Don't know how to handle message: " + message.what, new Exception());
        return false;
    }

    public boolean isConnectionCallbacksRegistered(ConnectionCallbacks connectionCallbacks) {
        boolean contains;
        zzaa.zzy(connectionCallbacks);
        synchronized (this.zzako) {
            contains = this.Ef.contains(connectionCallbacks);
        }
        return contains;
    }

    public boolean isConnectionFailedListenerRegistered(OnConnectionFailedListener onConnectionFailedListener) {
        boolean contains;
        zzaa.zzy(onConnectionFailedListener);
        synchronized (this.zzako) {
            contains = this.Eh.contains(onConnectionFailedListener);
        }
        return contains;
    }

    public void registerConnectionCallbacks(ConnectionCallbacks connectionCallbacks) {
        zzaa.zzy(connectionCallbacks);
        synchronized (this.zzako) {
            if (this.Ef.contains(connectionCallbacks)) {
                String valueOf = String.valueOf(connectionCallbacks);
                Log.w("GmsClientEvents", new StringBuilder(String.valueOf(valueOf).length() + 62).append("registerConnectionCallbacks(): listener ").append(valueOf).append(" is already registered").toString());
            } else {
                this.Ef.add(connectionCallbacks);
            }
        }
        if (this.Ee.isConnected()) {
            this.mHandler.sendMessage(this.mHandler.obtainMessage(1, connectionCallbacks));
        }
    }

    public void registerConnectionFailedListener(OnConnectionFailedListener onConnectionFailedListener) {
        zzaa.zzy(onConnectionFailedListener);
        synchronized (this.zzako) {
            if (this.Eh.contains(onConnectionFailedListener)) {
                String valueOf = String.valueOf(onConnectionFailedListener);
                Log.w("GmsClientEvents", new StringBuilder(String.valueOf(valueOf).length() + 67).append("registerConnectionFailedListener(): listener ").append(valueOf).append(" is already registered").toString());
            } else {
                this.Eh.add(onConnectionFailedListener);
            }
        }
    }

    public void unregisterConnectionCallbacks(ConnectionCallbacks connectionCallbacks) {
        zzaa.zzy(connectionCallbacks);
        synchronized (this.zzako) {
            if (!this.Ef.remove(connectionCallbacks)) {
                String valueOf = String.valueOf(connectionCallbacks);
                Log.w("GmsClientEvents", new StringBuilder(String.valueOf(valueOf).length() + 52).append("unregisterConnectionCallbacks(): listener ").append(valueOf).append(" not found").toString());
            } else if (this.Ek) {
                this.Eg.add(connectionCallbacks);
            }
        }
    }

    public void unregisterConnectionFailedListener(OnConnectionFailedListener onConnectionFailedListener) {
        zzaa.zzy(onConnectionFailedListener);
        synchronized (this.zzako) {
            if (!this.Eh.remove(onConnectionFailedListener)) {
                String valueOf = String.valueOf(onConnectionFailedListener);
                Log.w("GmsClientEvents", new StringBuilder(String.valueOf(valueOf).length() + 57).append("unregisterConnectionFailedListener(): listener ").append(valueOf).append(" not found").toString());
            }
        }
    }

    public void zzawc() {
        this.Ei = false;
        this.Ej.incrementAndGet();
    }

    public void zzawd() {
        this.Ei = true;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void zzgn(int r6) {
        /*
        r5 = this;
        r0 = 0;
        r1 = 1;
        r2 = android.os.Looper.myLooper();
        r3 = r5.mHandler;
        r3 = r3.getLooper();
        if (r2 != r3) goto L_0x000f;
    L_0x000e:
        r0 = r1;
    L_0x000f:
        r2 = "onUnintentionalDisconnection must only be called on the Handler thread";
        com.google.android.gms.common.internal.zzaa.zza(r0, r2);
        r0 = r5.mHandler;
        r0.removeMessages(r1);
        r1 = r5.zzako;
        monitor-enter(r1);
        r0 = 1;
        r5.Ek = r0;	 Catch:{ all -> 0x005f }
        r0 = new java.util.ArrayList;	 Catch:{ all -> 0x005f }
        r2 = r5.Ef;	 Catch:{ all -> 0x005f }
        r0.<init>(r2);	 Catch:{ all -> 0x005f }
        r2 = r5.Ej;	 Catch:{ all -> 0x005f }
        r2 = r2.get();	 Catch:{ all -> 0x005f }
        r3 = r0.iterator();	 Catch:{ all -> 0x005f }
    L_0x0031:
        r0 = r3.hasNext();	 Catch:{ all -> 0x005f }
        if (r0 == 0) goto L_0x0049;
    L_0x0037:
        r0 = r3.next();	 Catch:{ all -> 0x005f }
        r0 = (com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks) r0;	 Catch:{ all -> 0x005f }
        r4 = r5.Ei;	 Catch:{ all -> 0x005f }
        if (r4 == 0) goto L_0x0049;
    L_0x0041:
        r4 = r5.Ej;	 Catch:{ all -> 0x005f }
        r4 = r4.get();	 Catch:{ all -> 0x005f }
        if (r4 == r2) goto L_0x0053;
    L_0x0049:
        r0 = r5.Eg;	 Catch:{ all -> 0x005f }
        r0.clear();	 Catch:{ all -> 0x005f }
        r0 = 0;
        r5.Ek = r0;	 Catch:{ all -> 0x005f }
        monitor-exit(r1);	 Catch:{ all -> 0x005f }
        return;
    L_0x0053:
        r4 = r5.Ef;	 Catch:{ all -> 0x005f }
        r4 = r4.contains(r0);	 Catch:{ all -> 0x005f }
        if (r4 == 0) goto L_0x0031;
    L_0x005b:
        r0.onConnectionSuspended(r6);	 Catch:{ all -> 0x005f }
        goto L_0x0031;
    L_0x005f:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x005f }
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.common.internal.zzk.zzgn(int):void");
    }

    public void zzn(ConnectionResult connectionResult) {
        zzaa.zza(Looper.myLooper() == this.mHandler.getLooper(), (Object) "onConnectionFailure must only be called on the Handler thread");
        this.mHandler.removeMessages(1);
        synchronized (this.zzako) {
            ArrayList arrayList = new ArrayList(this.Eh);
            int i = this.Ej.get();
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                OnConnectionFailedListener onConnectionFailedListener = (OnConnectionFailedListener) it.next();
                if (!this.Ei || this.Ej.get() != i) {
                    return;
                } else if (this.Eh.contains(onConnectionFailedListener)) {
                    onConnectionFailedListener.onConnectionFailed(connectionResult);
                }
            }
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void zzp(android.os.Bundle r6) {
        /*
        r5 = this;
        r2 = 0;
        r1 = 1;
        r0 = android.os.Looper.myLooper();
        r3 = r5.mHandler;
        r3 = r3.getLooper();
        if (r0 != r3) goto L_0x006f;
    L_0x000e:
        r0 = r1;
    L_0x000f:
        r3 = "onConnectionSuccess must only be called on the Handler thread";
        com.google.android.gms.common.internal.zzaa.zza(r0, r3);
        r3 = r5.zzako;
        monitor-enter(r3);
        r0 = r5.Ek;	 Catch:{ all -> 0x0081 }
        if (r0 != 0) goto L_0x0071;
    L_0x001c:
        r0 = r1;
    L_0x001d:
        com.google.android.gms.common.internal.zzaa.zzbs(r0);	 Catch:{ all -> 0x0081 }
        r0 = r5.mHandler;	 Catch:{ all -> 0x0081 }
        r4 = 1;
        r0.removeMessages(r4);	 Catch:{ all -> 0x0081 }
        r0 = 1;
        r5.Ek = r0;	 Catch:{ all -> 0x0081 }
        r0 = r5.Eg;	 Catch:{ all -> 0x0081 }
        r0 = r0.size();	 Catch:{ all -> 0x0081 }
        if (r0 != 0) goto L_0x0073;
    L_0x0031:
        com.google.android.gms.common.internal.zzaa.zzbs(r1);	 Catch:{ all -> 0x0081 }
        r0 = new java.util.ArrayList;	 Catch:{ all -> 0x0081 }
        r1 = r5.Ef;	 Catch:{ all -> 0x0081 }
        r0.<init>(r1);	 Catch:{ all -> 0x0081 }
        r1 = r5.Ej;	 Catch:{ all -> 0x0081 }
        r1 = r1.get();	 Catch:{ all -> 0x0081 }
        r2 = r0.iterator();	 Catch:{ all -> 0x0081 }
    L_0x0045:
        r0 = r2.hasNext();	 Catch:{ all -> 0x0081 }
        if (r0 == 0) goto L_0x0065;
    L_0x004b:
        r0 = r2.next();	 Catch:{ all -> 0x0081 }
        r0 = (com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks) r0;	 Catch:{ all -> 0x0081 }
        r4 = r5.Ei;	 Catch:{ all -> 0x0081 }
        if (r4 == 0) goto L_0x0065;
    L_0x0055:
        r4 = r5.Ee;	 Catch:{ all -> 0x0081 }
        r4 = r4.isConnected();	 Catch:{ all -> 0x0081 }
        if (r4 == 0) goto L_0x0065;
    L_0x005d:
        r4 = r5.Ej;	 Catch:{ all -> 0x0081 }
        r4 = r4.get();	 Catch:{ all -> 0x0081 }
        if (r4 == r1) goto L_0x0075;
    L_0x0065:
        r0 = r5.Eg;	 Catch:{ all -> 0x0081 }
        r0.clear();	 Catch:{ all -> 0x0081 }
        r0 = 0;
        r5.Ek = r0;	 Catch:{ all -> 0x0081 }
        monitor-exit(r3);	 Catch:{ all -> 0x0081 }
        return;
    L_0x006f:
        r0 = r2;
        goto L_0x000f;
    L_0x0071:
        r0 = r2;
        goto L_0x001d;
    L_0x0073:
        r1 = r2;
        goto L_0x0031;
    L_0x0075:
        r4 = r5.Eg;	 Catch:{ all -> 0x0081 }
        r4 = r4.contains(r0);	 Catch:{ all -> 0x0081 }
        if (r4 != 0) goto L_0x0045;
    L_0x007d:
        r0.onConnected(r6);	 Catch:{ all -> 0x0081 }
        goto L_0x0045;
    L_0x0081:
        r0 = move-exception;
        monitor-exit(r3);	 Catch:{ all -> 0x0081 }
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.common.internal.zzk.zzp(android.os.Bundle):void");
    }
}
