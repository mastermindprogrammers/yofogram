package com.google.android.gms.common.util;

import java.util.regex.Pattern;

public class zzv {
    private static final Pattern GG;

    static {
        GG = Pattern.compile("\\$\\{(.*?)\\}");
    }

    public static boolean zzij(String str) {
        return str == null || str.trim().isEmpty();
    }
}
