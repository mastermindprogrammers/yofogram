package com.google.android.gms.common.util;

import android.os.Build.VERSION;

public final class zzs {
    public static boolean isAtLeastN() {
        return VERSION.SDK_INT >= 24;
    }

    public static boolean zzayn() {
        return VERSION.SDK_INT >= 11;
    }

    public static boolean zzayo() {
        return VERSION.SDK_INT >= 12;
    }

    public static boolean zzayp() {
        return VERSION.SDK_INT >= 13;
    }

    public static boolean zzayq() {
        return VERSION.SDK_INT >= 14;
    }

    public static boolean zzayr() {
        return VERSION.SDK_INT >= 16;
    }

    public static boolean zzays() {
        return VERSION.SDK_INT >= 17;
    }

    public static boolean zzayt() {
        return VERSION.SDK_INT >= 18;
    }

    public static boolean zzayu() {
        return VERSION.SDK_INT >= 19;
    }

    public static boolean zzayv() {
        return VERSION.SDK_INT >= 20;
    }

    @Deprecated
    public static boolean zzayw() {
        return zzayx();
    }

    public static boolean zzayx() {
        return VERSION.SDK_INT >= 21;
    }

    public static boolean zzayy() {
        return VERSION.SDK_INT >= 23;
    }
}
