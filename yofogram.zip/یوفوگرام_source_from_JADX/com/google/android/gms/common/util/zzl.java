package com.google.android.gms.common.util;

import java.util.regex.Pattern;

public final class zzl {
    private static Pattern Gy;

    static {
        Gy = null;
    }

    public static int zzhh(int i) {
        return i / PressureCooker.PRESSURE_UPDATE_STEPS_NORMAL;
    }
}
