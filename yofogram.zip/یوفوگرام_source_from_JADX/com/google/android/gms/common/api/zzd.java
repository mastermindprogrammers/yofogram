package com.google.android.gms.common.api;

import android.support.annotation.NonNull;

public class zzd extends zza {
    public zzd(@NonNull Status status) {
        super(status);
    }
}
