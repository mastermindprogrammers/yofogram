package com.google.android.gms.common.api;

public interface Releasable {
    void release();
}
